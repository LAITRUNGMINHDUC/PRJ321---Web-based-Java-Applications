/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab.Utils;

/**
 *
 * @author duclt
 */
public class AppENV {

    public static final String PAGE_LOGIN = "index.jsp";
    public static final String PAGE_VIEW = "view.jsp";
    public static final String PAGE_VIEWDETAILS = "viewDetails.jsp";

    public static final String SERVLET_LOGIN = "LoginServlet";
    public static final String SERVLET_SEARCH = "SearchServlet";
    public static final String SERVLET_VIEWDETAIL = "ViewServlet";

    public static final String BT_LOGIN = "Login";
    public static final String BT_SEARCH = "Search";
    public static final String BT_VIEW = "View";

    public static final String CONTROLLER = "Controller";
    public static final String ERROR_LOGIN = "errLoginPage.html";
    public static final String ERROR = "errPage.jsp";

}
